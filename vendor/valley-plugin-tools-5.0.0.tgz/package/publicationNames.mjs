import fs from 'node:fs/promises'
import path from 'node:path'

// Publication-name scan for built plugin assets (L1293; was Excalidraw's own build step and asset test). The names are
// never part of a package: the publisher supplies them in VALLEY_PUBLICATION_NAMES (comma-separated), and `valley-plugin
// build` and `valley-plugin scan [dir]` then refuse generated assets that contain one, coincidental base64 runs included.
const MIN_LENGTH = 3
const quote = (value) => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
const pattern = (names) => new RegExp(names.map(quote).join('|'), 'gi')

/** The names to keep out of published assets, from the environment only. */
export function publicationNames(env = process.env) {
  return String(env.VALLEY_PUBLICATION_NAMES ?? '').split(',').map((name) => name.trim()).filter((name) => name.length >= MIN_LENGTH)
}

/** Every occurrence of a name in the files below `root` (bytes read as latin1), as root-relative POSIX paths. */
export async function scanPublicationNames(root, names = publicationNames()) {
  if (!names.length) return []
  const matcher = pattern(names), found = []
  const files = (await fs.readdir(root, { recursive: true, withFileTypes: true })).filter((entry) => entry.isFile())
    .map((entry) => path.join(entry.parentPath, entry.name)).sort()
  for (const file of files) {
    const text = (await fs.readFile(file)).toString('latin1')
    for (const match of text.matchAll(matcher)) found.push({ file: path.relative(root, file).split(path.sep).join('/'), offset: match.index, length: match[0].length })
  }
  return found
}

/**
 * A JSON string literal with every name's first character written as a `\uXXXX` escape: the decoded value (a font or
 * image data URL) is unchanged, its bytes no longer contain the name. Throws when the value would change.
 */
export function escapePublicationNames(literal, names = publicationNames()) {
  if (!names.length) return literal
  const matcher = pattern(names)
  const escaped = literal.replace(matcher, (name) => `\\u${name.charCodeAt(0).toString(16).padStart(4, '0').toUpperCase()}${name.slice(1)}`)
  if (JSON.parse(escaped) !== JSON.parse(literal) || escaped.search(pattern(names)) !== -1) throw new Error('The publication-name escape changed the asset value')
  return escaped
}

/** Throws with the first matches when `root` contains a publication name. */
export async function assertNoPublicationNames(root, names = publicationNames()) {
  const found = await scanPublicationNames(root, names)
  if (found.length) throw new Error(`Publication names in generated assets (${found.length}): ${found.slice(0, 8).map(({ file, offset }) => `${file}@${offset}`).join(', ')}`)
  return found
}
