export function sourceFiles(root: string): Promise<string[]>
export function checkPlugin(root: string): Promise<{ pkg: Record<string, unknown>; manifest: Record<string, unknown>; config: Record<string, unknown> }>
export function buildPlugin(options?: { root?: string; outDir?: string; mode?: 'development' | 'production' }): Promise<{ outDir: string; metafile: unknown }>
export const PLUGIN_JSX_OPTIONS: { readonly jsx: 'transform'; readonly jsxFactory: 'React.createElement'; readonly jsxFragment: 'React.Fragment' }
export function replaceDirectory(staged: string, destination: string): Promise<void>
export function publicationNames(env?: Record<string, string | undefined>): string[]
export function scanPublicationNames(root: string, names?: string[]): Promise<Array<{ file: string; offset: number; length: number }>>
export function assertNoPublicationNames(root: string, names?: string[]): Promise<Array<{ file: string; offset: number; length: number }>>
export function escapePublicationNames(literal: string, names?: string[]): string
export function readPluginLocales(root: string, config: Record<string, unknown>, manifest: Record<string, unknown>, runtime?: boolean): Promise<Record<string, Record<string, string>>>

export function validatePluginSource(code: string, file?: string): string[]
export function overflowMenuDiagnostics(code: string, names: string[], file?: string): string[]
