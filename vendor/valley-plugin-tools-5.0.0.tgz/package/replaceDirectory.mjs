import fs from 'node:fs/promises'

export async function replaceDirectory(staged, destination) {
  const backup = `${staged}.previous`
  let backedUp = false
  try { await fs.rename(destination, backup); backedUp = true } catch (error) { if (error.code !== 'ENOENT') throw error }
  try { await fs.rename(staged, destination) } catch (error) {
    if (backedUp) {
      try { await fs.rename(backup, destination) } catch (restoreError) {
        throw new AggregateError([error, restoreError], `Runtime replacement and restoration failed; previous runtime preserved at ${backup}`)
      }
    }
    throw error
  }
  if (backedUp) await fs.rm(backup, { recursive: true, force: true })
}
