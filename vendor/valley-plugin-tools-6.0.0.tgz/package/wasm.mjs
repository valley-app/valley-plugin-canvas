import fs from 'node:fs/promises'
import { existsSync, readFileSync } from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawn, execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'

// WebAssembly modules of a plugin package (SDK 7, plan 12.3): `src/wasm/` holds the crate, `runtime/assets/<id>.wasm`
// the committed module. The step is conditional: a package without `src/wasm/Cargo.toml` never needs cargo.
export const WASM_TARGET = 'wasm32-unknown-unknown'
export const WASM_CRATE = 'src/wasm'
// The features rustc's generic wasm32 CPU emits; wasm-opt must accept exactly these (tooling/build/build-rust.mjs).
const WASM_FEATURES = ['bulk-memory', 'bulk-memory-opt', 'call-indirect-overlong', 'multivalue', 'mutable-globals', 'nontrapping-float-to-int', 'reference-types', 'sign-ext']
// The GitHub and community installers download one zipball of at most 32 MiB; check keeps headroom below it.
export const PACKAGE_ZIP_ESTIMATE_LIMIT = 28 * 1024 * 1024

export const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex')
const exe = (name) => process.platform === 'win32' ? `${name}.exe` : name

export const hasWasmCrate = (root) => existsSync(path.join(root, WASM_CRATE, 'Cargo.toml'))

/** The toolchain pins plugin-tools ships (`rust-toolchain.json`, copied from the app at `build:portable-packages`). */
export function readPinnedToolchain(file = new URL('./rust-toolchain.json', import.meta.url)) {
  try { return JSON.parse(readFileSync(file, 'utf8')) } catch (error) {
    if (error.code === 'ENOENT') throw new Error('plugin-tools carries no rust-toolchain.json: use a packed plugin-tools archive (npm run build:portable-packages in the Valley app)')
    throw error
  }
}

export const missingCargoMessage = (command = 'cargo') => `${command} was not found on PATH. This package builds WebAssembly from ${WASM_CRATE}/Cargo.toml: install rustup (https://rustup.rs); the package's rust-toolchain.toml selects the pinned toolchain and the ${WASM_TARGET} target`

function binaryenKey(platform = process.platform, arch = process.arch) {
  const system = { darwin: 'macos', linux: 'linux', win32: 'windows' }[platform]
  const cpu = arch === 'x64' ? 'x86_64' : arch === 'arm64' ? (platform === 'linux' ? 'aarch64' : 'arm64') : null
  return system && cpu ? `${cpu}-${system}` : null
}

/** `VALLEY_WASM_OPT`, then the Valley tools cache (`npm run rust:tools`), then `wasm-opt` on PATH; its version must equal the pin. */
export function resolveWasmOpt(toolchain, env = process.env) {
  const version = toolchain.binaryen.version
  const key = binaryenKey()
  const cache = env.VALLEY_RUST_TOOLS_DIR || path.join(env.CARGO_HOME || path.join(os.homedir(), '.cargo'), 'valley-tools')
  const cached = key && path.join(cache, `binaryen-${version}-${key}`, `binaryen-${version}`, 'bin', exe('wasm-opt'))
  const binary = env.VALLEY_WASM_OPT || (cached && existsSync(cached) ? cached : 'wasm-opt')
  const wanted = version.replace(/^version_/, '')
  let found
  try { found = execFileSync(binary, ['--version'], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], env }).trim() } catch (error) {
    if (error.code === 'ENOENT') throw new Error(`wasm-opt was not found: install binaryen ${version} (${toolchain.binaryen.url.replace('{platform}', key ?? '<platform>')}, sha256 pinned in plugin-tools' rust-toolchain.json) and put its bin/ on PATH, or set VALLEY_WASM_OPT`)
    throw error
  }
  if (!new RegExp(`\\bversion ${wanted}\\b`).test(found)) throw new Error(`wasm-opt ${found} found, binaryen ${version} pinned: install that release or set VALLEY_WASM_OPT`)
  return binary
}

function run(command, args, { cwd, env }) {
  return new Promise((resolve, reject) => {
    const stdout = [], stderr = []
    const child = spawn(command, args, { cwd, env, stdio: ['ignore', 'pipe', 'pipe'] })
    child.stdout.on('data', (chunk) => stdout.push(chunk))
    child.stderr.on('data', (chunk) => stderr.push(chunk))
    child.on('error', (error) => reject(error.code === 'ENOENT' && ['cargo', 'rustc'].includes(command) ? new Error(missingCargoMessage(command)) : error))
    child.on('close', (code) => {
      const out = Buffer.concat(stdout).toString('utf8'), err = Buffer.concat(stderr).toString('utf8')
      if (code === 0) resolve({ stdout: out, stderr: err })
      else reject(new Error(`${command} ${args.join(' ')} failed with exit ${code}\n${err}${out}`.trimEnd()))
    })
  })
}

/**
 * One release build of the package's crate into a fresh target directory, then `wasm-opt -Os --strip-debug`.
 * The staged root, the cargo registry and the rustc sysroot are remapped so the bytes do not depend on where the
 * package or the toolchain lives; `--config build.rustflags` is joined with the crate's own `.cargo/config.toml`
 * (`--import-memory`, `--max-memory`). Returns each cdylib's optimized bytes by its file stem.
 */
export async function buildWasmCrateOnce({ root, toolchain, env = process.env }) {
  // Cargo reads .cargo/config.toml from every directory above the crate, and config profiles override Cargo.toml, so a
  // package inside another project (an app repository, a workspace) would build different bytes. The crate is built
  // from a copy in a fresh directory outside any checkout, with the package's rust-toolchain.toml beside it.
  const stage = await fs.realpath(await fs.mkdtemp(path.join(os.tmpdir(), 'valley-plugin-crate-')))
  try {
    await fs.cp(path.join(root, WASM_CRATE), path.join(stage, WASM_CRATE), { recursive: true, filter: (entry) => path.basename(entry) !== 'target' })
    for (const file of ['rust-toolchain.toml', 'rust-toolchain']) await fs.copyFile(path.join(root, file), path.join(stage, file)).catch((error) => { if (error.code !== 'ENOENT') throw error })
    return await buildStagedCrate({ root: stage, toolchain, env })
  } finally { await fs.rm(stage, { recursive: true, force: true }) }
}

async function buildStagedCrate({ root, toolchain, env }) {
  const crate = path.join(root, WASM_CRATE)
  const cargoHome = env.CARGO_HOME || path.join(os.homedir(), '.cargo')
  const { stdout: sysroot } = await run('rustc', ['--print', 'sysroot'], { cwd: crate, env })
  const remaps = [`--remap-path-prefix=${root}=/plugin`, `--remap-path-prefix=${path.join(cargoHome, 'registry', 'src')}=/cargo-registry`, `--remap-path-prefix=${sysroot.trim()}=/rustc`]
  const target = await fs.mkdtemp(path.join(os.tmpdir(), 'valley-plugin-wasm-'))
  try {
    const { stdout } = await run('cargo', ['build', '--release', '--locked', '--target', WASM_TARGET, '--message-format=json-render-diagnostics', '--config', `build.rustflags=${JSON.stringify(remaps)}`], {
      cwd: crate, env: { ...env, CARGO_TARGET_DIR: target, CARGO_INCREMENTAL: '0', CARGO_TERM_COLOR: 'never' }
    })
    const artifacts = stdout.split('\n').filter((line) => line.startsWith('{')).map((line) => JSON.parse(line))
      .filter((message) => message.reason === 'compiler-artifact' && message.target?.kind?.includes('cdylib'))
      .flatMap((message) => message.filenames.filter((file) => file.endsWith('.wasm')))
    if (!artifacts.length) throw new Error(`${WASM_CRATE} built no cdylib: set [lib] crate-type = ["cdylib"]`)
    const wasmOpt = resolveWasmOpt(toolchain, env)
    const built = {}
    for (const file of artifacts) {
      const optimized = path.join(target, `${path.basename(file, '.wasm')}.opt.wasm`)
      await run(wasmOpt, ['-Os', '--strip-debug', '--mvp-features', ...WASM_FEATURES.map((feature) => `--enable-${feature}`), file, '-o', optimized], { cwd: crate, env })
      built[path.basename(file, '.wasm')] = await fs.readFile(optimized)
    }
    return built
  } finally { await fs.rm(target, { recursive: true, force: true }) }
}

/** Which built artifact a declaration takes: a single module takes the only artifact, otherwise the artifact named like its id. */
export function artifactFor(declaration, built, declarations) {
  const stems = Object.keys(built)
  const stem = declarations.length === 1 && stems.length === 1 ? stems[0] : declaration.id.replaceAll('-', '_')
  const bytes = built[stem]
  if (!bytes) throw new Error(`runtime.wasm ${declaration.id}: ${WASM_CRATE} built ${stems.join(', ') || 'nothing'}; name the cdylib ${declaration.id.replaceAll('-', '_')} or declare one module`)
  return bytes
}

/** Builds the crate twice, each time into a fresh target directory, and requires identical bytes for every artifact. */
export async function buildWasmModules({ root, toolchain = readPinnedToolchain(), env = process.env }) {
  const first = await buildWasmCrateOnce({ root, toolchain, env })
  const second = await buildWasmCrateOnce({ root, toolchain, env })
  for (const [stem, bytes] of Object.entries(first)) {
    if (!second[stem] || !bytes.equals(second[stem])) throw new Error(`${WASM_CRATE}: two builds of ${stem} produced different bytes; the build is not reproducible`)
  }
  return first
}

/**
 * Builds the modules (twice, identical bytes), then checks each declared module's sha256 against the committed
 * declaration. A mismatch fails, naming the built digest, so a changed module is committed explicitly.
 */
export async function buildPluginWasm({ root, config, toolchain = readPinnedToolchain(), env = process.env }) {
  const declarations = config.runtime?.wasm ?? []
  if (!declarations.length) throw new Error(`${WASM_CRATE}/Cargo.toml exists but config.runtime.wasm declares no module`)
  const built = await buildWasmModules({ root, toolchain, env })
  const modules = []
  for (const declaration of declarations) {
    const bytes = artifactFor(declaration, built, declarations)
    const digest = sha256(bytes)
    if (digest !== declaration.sha256) throw new Error(`runtime.wasm ${declaration.id}: the built module has sha256 ${digest}, config.json declares ${declaration.sha256}; commit the new digest to release it`)
    modules.push({ declaration, bytes })
  }
  return modules
}

/**
 * The byte rules for declared modules (the host's, through the installed SDK's `pluginWasm` module): size limits,
 * WebAssembly validity, imports within the allowlist, `env.memory` imported and no memory exported or defined,
 * declared exports present. `bytes` maps a declaration id to its module bytes.
 */
export async function wasmModuleDiagnostics({ declarations, bytes, sdk }) {
  const issues = []
  let total = 0
  for (const declaration of declarations) {
    const module = bytes.get(declaration.id)
    if (!module) continue
    total += module.byteLength
    if (module.byteLength > sdk.PLUGIN_WASM_LIMITS.moduleBytes) issues.push(`${declaration.id} is ${module.byteLength} bytes, above the ${sdk.PLUGIN_WASM_LIMITS.moduleBytes}-byte module limit`)
    if (!WebAssembly.validate(module)) { issues.push(`${declaration.id} is not a valid WebAssembly module`); continue }
    let info
    try { info = sdk.inspectPluginWasmBinary(module) } catch (error) { issues.push(`${declaration.id}: ${error.message}`); continue }
    for (const issue of sdk.pluginWasmModuleIssues(info, declaration)) issues.push(`${declaration.id} ${issue}`)
  }
  if (total > sdk.PLUGIN_WASM_LIMITS.totalBytes) issues.push(`modules total ${total} bytes, above the ${sdk.PLUGIN_WASM_LIMITS.totalBytes}-byte plugin limit`)
  return issues
}
